
#include "sortingcompetition.h"
#include <fstream>
#include <chrono>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <string>
#include <sstream>
#include <emscripten/bind.h>

using namespace emscripten;

using namespace std;

#include "../../../../../../emsdk/upstream/emscripten/system/include/emscripten/websocket.h"
#include <assert.h>
#include "json.hpp"
using namespace nlohmann;

//Initializes all the data
SortingCompetition::SortingCompetition(){
    filename = "";
    data = {};
    dataCopy = {};
    container = {};
    wordCount = 0;
    start = 0;
    size = 80;
}

//Creates ifstream object with input file name
SortingCompetition::SortingCompetition(const string& inputFileName){
    ifstream inFile(inputFileName);
}

//Sets the input file name
void SortingCompetition::setFileName(const string& inputFileName){
    filename = inputFileName;
}

//Reads data from the file and store it in a instance-level linear data structure
string SortingCompetition::readData(){
    inFile.open(filename.c_str());
    //Checks if file was opened successfully
    string inFileData;
    if (!inFile){
        cerr << "File could not be opened" << endl;
        return "";
    }

    //Extracts number of words to sort and converts it to an int
    inFile >> inFileData;
    wordCount = atoi(inFileData.c_str());

    unsigned int count = 0;      //Keeps track of words to read
    data.clear();       //Makes sure vector is cleared before data is stored
    //Reads words from file and stores in vector
    while(count < wordCount){
        inFile >> inFileData;
        data.push_back(inFileData);
        count++;
    }

    std::ifstream input(filename.c_str());
    std::stringstream sstr;

    while(input >> sstr.rdbuf());

    // cout << "Data read: " << sstr.str() << endl;


    return sstr.str();
}

//Copies data from the original data structure into second
//location that will be used for sorting
bool SortingCompetition::prepareData(vector <string> data){
    dataCopy.clear();
    dataCopy = data;
    return true;
}

//Sorts copy of data based on length of words first
//then calls Quicksort on subvector to sort alphabetically
void SortingCompetition::sortData(vector <string> dataCopy){
    //Stores copy of data in a vector of vectors to sort by length
    container.resize(size);
    for(unsigned int i = 0; i < size; i++)
        container[i].clear();
    for (unsigned int i = 0; i < dataCopy.size(); i++)
        container[dataCopy[i].size()].push_back(dataCopy[i]);


    //Calls Quicksort to sort subvector alphabetically

    // Single Threaded
    for (unsigned int k = 0; k < size; k++)
        if (container[k].size() > 0)
            quickSort(container[k], start, container[k].size()-1);

    // Multi Threaded
    // int numCores = thread::hardware_concurrency();
    // cout << "We have " << numCores << " cores" << endl;

    // std::vector<std::thread> threads;

    // for (int i = 0; i < numCores; ++i){
    //     //anonymous lambda
    //     threads.push_back(std::thread([this](){
    //         for (unsigned int k = 0; k < size; k++)
    //             if (container[k].size() > 0)
    //                 quickSort(container[k], start, container[k].size()-1);
    //     }));
    // }
    
    // for (auto &th : threads)
    //     th.join();
}

//Splits the array passed as parameter into two sub-arrays.
//The first sub-array is sorted and increases in size as the sort continues
//The second sub-array is unsorted, it contains all the elements to yet be inserted into the first sub-array
//and decreases in size as the sort continues.
void SortingCompetition::insertionSort(vector <string> &inputVec, int size){
    for (unsigned int i = 1; i < size; i++){
        unsigned int j;
        string temp = inputVec[i];
        for (j = i; j > 0 && inputVec[j - 1] > temp; j--)
            inputVec[j] = inputVec[j - 1];
        inputVec[j] = temp;
    }
}

//Partitions the vector passed into 3 partitions.
//One with the elements that are less than the pivot (indexes left to i)
//A second one with the elements that are the same as the pivot (indexes i+1 to j)
//A last one with the elements that are greater than the pivot (indexes j+1 to right)
void SortingCompetition::partition(vector<string> &inputVec, int left ,int right, int &i, int &j){
    i = left - 1;
    j = right;
    int countLeft = left - 1;
    int countRight = right;
    string pivot = inputVec[right];

    while (true){
        //Find the first element greater than or equal to pivot.
        //This loop will definitely terminate as pivot is last element
        while (inputVec[++i] < pivot);

        //Find the first element smaller than or equal to pivot
        while (pivot < inputVec[--j])
            if (j == left)
                break;

        //If indexes cross, terminate
        if (i >= j) break;

        //Smaller goes on left side of pivot and greater goes on right side of pivot
        swap(inputVec[i], inputVec[j]);

        //Move all same left occurrences of pivot to beginning of array and keep count using countLeft
        if (inputVec[i] == pivot){
            countLeft++;
            swap(inputVec[countLeft], inputVec[i]);
        }

        //Move all same right occurrences of pivot to end of array and keep count using countRight
        if (inputVec[j] == pivot){
            countRight--;
            swap(inputVec[j], inputVec[countRight]);
        }
    }

    //Move pivot element to correct index
    swap(inputVec[i], inputVec[right]);

    //Move all left same occurrences of pivot to inputVec[j]
    j = i - 1;
    for (int k = left; k < countLeft; k++, j--)
        swap(inputVec[k], inputVec[j]);

    //Move all right same occurrences of pivot to inputVec[i]
    i = i + 1;
    for (int k = right - 1; k > countRight; k--, i++)
        swap(inputVec[i], inputVec[k]);
}

//Sorts recursively using Quicksort with 3-way partitioning
void SortingCompetition::quickSort(vector<string> &inputVec, int left, int right) {
    unsigned int threshold = 10;
    //Checks if indexes have crossed to terminate
    if (right <= left)
        return;

    //Uses insertion when vector becomes small
    if (inputVec.size() < threshold){
        insertionSort(inputVec, inputVec.size());
        return;
    }

    //Partitions the vector into 3 then calls quickSort recusrsively on the left and right partitions
    int i, j;
    partition(inputVec, left, right, i, j); //i and j passed as reference

    // Single Threaded
    quickSort(inputVec, left, j);
    quickSort(inputVec, i, right);

    //Multi Threaded
    // std::thread t1([&]() {
    //         quickSort(inputVec, left, j);
    // });
    // std::thread t2([&]() {
    //         quickSort(inputVec, i, right);
    // });
    // t1.join();
    // t2.join();
}

//Writes the "sorted" data structure to the file as a newline-delimited list
vector <string> SortingCompetition::outputData(const string &outputFileName){
    vector<string> x = {};
    for(unsigned int i = 0; i < size; i++){
        for (unsigned int j = 0; j < container[i].size(); j++){
            // cout << container[i][j] << endl;
            x.push_back(container[i][j]);
        }
    }

    string * arr = new string [x.size()]; 

    for (int i = 0; i < x.size(); i++){
        arr[i] = x[i];
    }

    outFile.open(outputFileName.c_str());
    for(unsigned int i = 0; i < size; i++)
        for (unsigned int j = 0; j < container[i].size(); j++)
            outFile << container[i][j] << endl;
    outFile.close();
    return x;
}

int SortingCompetition::getSize(){
    return wordCount;
}

EMSCRIPTEN_BINDINGS(my_module) {
    register_vector<std::string>("");
    
    class_<SortingCompetition>("SortingCompetition")
    .constructor()
    .function("setFileName", &SortingCompetition::setFileName)
    .function("readData", &SortingCompetition::readData)
    .function("prepareData", &SortingCompetition::prepareData)
    .function("sortData", &SortingCompetition::sortData)
    .function("getSize", &SortingCompetition::getSize)
    .function("outputData", &SortingCompetition::outputData);
}
