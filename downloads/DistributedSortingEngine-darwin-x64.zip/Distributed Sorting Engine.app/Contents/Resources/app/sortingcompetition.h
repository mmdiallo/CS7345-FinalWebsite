/*
 Project 4: Sorting Competition
 Purpose: This program will sort a list of words from a text file. The words must be sorted according to the following conditions:
    Primary Sort Condition - Sort by length of word (number of characters)
    Secondary Sort Condition - Sort alphabetically Since this is a secondary sort condition, it will be applied to words
    that are all of the same length. So, all 2 letter words would be sorted alphabetically, all 3 letter words would be
    sorted alphabetically, and so on.
*/
#ifndef SORTINGCOMPETITION_H
#define SORTINGCOMPETITION_H
#include <iostream>
#include <fstream>
#include <chrono>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <string>
#include <functional>
#include <thread>
using namespace std;

class SortingCompetition{
private:
    string filename;
    ifstream inFile;
    ofstream outFile;
    vector <string> data;
    vector <string> dataCopy;
    vector<vector<string>> container;
    unsigned int wordCount;
    unsigned int start;
    unsigned int size;
    void insertionSort(vector <string> &, int);
    void partition(vector<string> &, int, int, int &, int &);
    void quickSort(vector<string> &, int, int);

public:
    SortingCompetition();
    SortingCompetition(const string& inputFileName);
    void setFileName(const string& inputFileName);
    string readData();
    bool prepareData(vector <string>);
    void sortData(vector <string>);
    vector <string> outputData(const string& outputFileName);
    int getSize();
};

#endif // SORTINGCOMPETITION_H
