#include "sortingcompetition.cpp"
#include <iomanip>
#include <chrono>

#include "../../../../../../emsdk/upstream/emscripten/system/include/emscripten/websocket.h"
#include <assert.h>
#include "json.hpp"
using namespace nlohmann;

EM_BOOL WebSocketOpen(int eventType, const EmscriptenWebSocketOpenEvent *e, void * userData){
    string msg = "{\"type\":\"msg\", \"data\":\"C++ Client Connected\"}";

    emscripten_websocket_send_utf8_text(e->socket, msg.c_str());

    return 0;
}

EM_BOOL WebSocketMessage(int eventType, const EmscriptenWebSocketMessageEvent *e, void * userData){

    if(e->isText){
        SortingCompetition sc;

        sc.setFileName("test.in");
        string data = sc.readData();

        string msgToRegister = "{\"type\":\"register\", \"data\":\"" + string(data) + "\"}";

        auto msgRcvd = json::parse(e->data);

        string id = msgRcvd["id"].get<string>();
        // cout << id << endl;
        printf("text data from server: \"%s\"\n", e->data);

        if(msgRcvd["type"] == "msg"){
            if (id == "controller"){
                emscripten_websocket_send_utf8_text(e->socket, msgToRegister.c_str());
            }

            else{
                string msg = "{\"type\":\"go\", \"data\":\"Ready to work\"}";
                emscripten_websocket_send_utf8_text(e->socket, msg.c_str());
            }
        }

        else if(msgRcvd["type"] == "process"){
            vector <string> d = msgRcvd["data"];
            sc.prepareData(d);
            sc.sortData(d);
            vector <string> result = sc.outputData("test.out");
            for(int i=0; i < result.size(); i++)
                std::cout << result.at(i) << ' ';

            json j;
            j["type"] = "result";
            j["id"] = id;
            j["data"] = result;

            emscripten_websocket_send_utf8_text(e->socket, (j.dump()).c_str());
        }
    }
    return 0;
}


int main(int argc, const char * argv[]){

    if(!emscripten_websocket_is_supported()){
        printf("Websockets are not supported, cannot continue\n");
        exit(1);
    }

    printf("Websockets are supported\n");
    EmscriptenWebSocketCreateAttributes attr;
    emscripten_websocket_init_create_attributes(&attr);

    const char *url = "ws://localhost:8080/";
    attr.url = url;
    attr.protocols = "binary,base64";
    attr.createOnMainThread = true;

    EMSCRIPTEN_WEBSOCKET_T socket = emscripten_websocket_new(&attr);

    if(socket <= 0){
        printf("Websocket creation failed, error code %d\n", (EMSCRIPTEN_RESULT)socket);
        exit(1);
    }

    //query websocket object
    //URL:
    int urlLength = 0;
    EMSCRIPTEN_RESULT res = emscripten_websocket_get_url_length(socket, &urlLength);
    assert(res == EMSCRIPTEN_RESULT_SUCCESS);
    assert(urlLength == strlen(url) +1);

    char url2[urlLength];
    res = emscripten_websocket_get_url(socket, url2, urlLength);
    printf("URL Request Complete\n");
    assert(res == EMSCRIPTEN_RESULT_SUCCESS);
    // printf("url: %s, verified: %s, length: %d\n", url, url2, urlLength);

    //register callbacks with ws obj
    printf("Websocket URL Query Complete\n");
    emscripten_websocket_set_onopen_callback(socket, NULL, WebSocketOpen);
    emscripten_websocket_set_onmessage_callback(socket, NULL, WebSocketMessage);

    printf("Websocket Callback Events Registered\n");

    return 0;
}